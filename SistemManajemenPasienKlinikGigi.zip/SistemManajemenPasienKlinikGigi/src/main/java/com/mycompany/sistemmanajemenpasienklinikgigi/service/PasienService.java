/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Asus
 */

package com.mycompany.sistemmanajemenpasienklinikgigi.service;

import java.util.ArrayList;
import java.util.Scanner;
import com.mycompany.sistemmanajemenpasienklinikgigi.model.Pasien;

public class PasienService {
    private ArrayList<Pasien> daftarPasien = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

public void tambahPasien() {
    String nama;
    do {
        System.out.print("Nama Pasien: ");
        nama = scanner.nextLine().trim();
        if (nama.isEmpty()) {
            System.out.println("Nama tidak boleh kosong!");
        }
    } while (nama.isEmpty());

    int umur;
    while (true) {
        try {
            System.out.print("Umur Pasien: ");
            umur = Integer.parseInt(scanner.nextLine());
            if (umur <= 0) {
                System.out.println("Umur harus lebih dari 0!");
                continue;
            }
            break;
        } catch (NumberFormatException e) {
            System.out.println("Input umur harus berupa angka!");
        }
    }

    String layanan = pilihLayanan();
    daftarPasien.add(new Pasien(nama, umur, layanan));
    System.out.println("Pasien berhasil ditambahkan!");
}

// 🔍 Fitur Search Pasien
public void cariPasien() {
    System.out.print("Masukkan nama pasien yang dicari: ");
    String keyword = scanner.nextLine().toLowerCase();

    boolean ditemukan = false;
    for (Pasien p : daftarPasien) {
        if (p.getNama().toLowerCase().contains(keyword)) {
            System.out.println("Ditemukan: " + p.getNama() +
                               " | Umur: " + p.getUmur() +
                               " | Layanan: " + p.getLayanan());
            ditemukan = true;
        }
    }

    if (!ditemukan) {
        System.out.println("Pasien dengan nama \"" + keyword + "\" tidak ditemukan.");
    }
}

    // Lihat Pasien
    public void lihatPasien() {
        System.out.println("\nDaftar Pasien:");
        if (daftarPasien.isEmpty()) {
            System.out.println("Belum ada pasien.");
        } else {
            for (int i = 0; i < daftarPasien.size(); i++) {
                Pasien p = daftarPasien.get(i);
                System.out.println((i+1) + ". " + p.getNama() +
                        " | Umur: " + p.getUmur() +
                        " | Layanan: " + p.getLayanan());
            }
        }
    }

    // Ubah Pasien
    public void ubahPasien() {
        System.out.print("Masukkan nomor pasien yang ingin diubah: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine();

        if (index >= 0 && index < daftarPasien.size()) {
            Pasien p = daftarPasien.get(index);
            System.out.print("Nama baru (" + p.getNama() + "): ");
            p.setNama(scanner.nextLine());
            System.out.print("Umur baru (" + p.getUmur() + "): ");
            p.setUmur(scanner.nextInt());
            scanner.nextLine();
            p.setLayanan(pilihLayanan());
            System.out.println("Data pasien berhasil diperbarui!");
        } else {
            System.out.println("Pasien tidak ditemukan.");
        }
    }

    
    // Hapus Pasien
    public void hapusPasien() {
        System.out.print("Masukkan nomor pasien yang ingin dihapus: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine();

        if (index >= 0 && index < daftarPasien.size()) {
            daftarPasien.remove(index);
            System.out.println("Pasien berhasil dihapus!");
        } else {
            System.out.println("Pasien tidak ditemukan.");
        }
    }

    // Menu layanan
    private String pilihLayanan() {
        while (true) {
            System.out.println("\nPilih Layanan:");
            System.out.println("1. Tambal Gigi");
            System.out.println("2. Cabut Gigi");
            System.out.println("3. Scaling");
            System.out.println("4. Kontrol Behel");
            System.out.print("Pilih layanan (1-4): ");
            int pilihan = scanner.nextInt();
            scanner.nextLine();

            return switch (pilihan) {
                case 1 -> "Tambal Gigi";
                case 2 -> "Cabut Gigi";
                case 3 -> "Scaling";
                case 4 -> "Kontrol Behel";
                default -> {
                    System.out.println("Pilihan tidak valid, coba lagi.");
                    yield null;
                }
            };
        }
    }
}
